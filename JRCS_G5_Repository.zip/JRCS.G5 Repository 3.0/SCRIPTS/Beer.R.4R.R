# ============================================================
# FULL Q1 PIPELINE: DATA → ANALYSIS → TIFF FIGURES (1–7)
# ============================================================

# -----------------------------
# 1. Load required packages
# -----------------------------
required_packages <- c(
  "dplyr", "ggplot2", "caret", "corrplot", "randomForest", "e1071"
)

for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
  }
  library(pkg, character.only = TRUE)
}

set.seed(123)

# -----------------------------
# 2. Load dataset
# -----------------------------
beer_data <- read.csv(
  "C:/Users/sahlw/OneDrive/Desktop/YNU2/PROJECT/BEER REVIEW PREDICTION/DATASET/beer review rdataset.csv",
  stringsAsFactors = FALSE
)

names(beer_data) <- make.names(names(beer_data), unique = TRUE)

# Drop useless columns
drop_cols <- c("X", "Unnamed..25")
drop_cols <- intersect(drop_cols, names(beer_data))
if (length(drop_cols) > 0) {
  beer_data <- beer_data %>% select(-all_of(drop_cols))
}

# -----------------------------
# 3. Data preprocessing
# -----------------------------
category_columns <- grep("^Category", names(beer_data), value = TRUE)

beer_data[category_columns] <- lapply(beer_data[category_columns], function(x) {
  suppressWarnings(as.numeric(as.character(x)))
})

for (col in category_columns) {
  med_val <- median(beer_data[[col]], na.rm = TRUE)
  beer_data[[col]][is.na(beer_data[[col]])] <- med_val
}

nzv <- nearZeroVar(beer_data[, category_columns], saveMetrics = TRUE)
category_columns <- rownames(nzv)[!nzv$nzv]

analysis_df <- beer_data[, category_columns, drop = FALSE]

# -----------------------------
# 4. Helper: TIFF export
# -----------------------------
save_tiff <- function(filename, plot_expr, width = 10, height = 8, res = 300) {
  tiff(filename,
       width = width,
       height = height,
       units = "in",
       res = res,
       compression = "lzw")
  eval(plot_expr)
  dev.off()
}

# ============================================================
# FIGURE 1 — HEATMAP
# ============================================================
cor_matrix <- cor(analysis_df, use = "pairwise.complete.obs")
cor_matrix[is.na(cor_matrix)] <- 0

save_tiff("Figure1_Heatmap.tiff", quote({
  corrplot(
    cor_matrix,
    method = "color",
    type = "upper",
    order = "hclust",
    addrect = 3,
    tl.col = "black",
    tl.cex = 0.7,
    col = colorRampPalette(c("#2166AC", "#F7F7F7", "#B2182B"))(200)
  )
  title("Correlation Heatmap of Beer Review Attributes", font.main = 2)
}))

# ============================================================
# PCA
# ============================================================
pca_res <- prcomp(analysis_df, scale. = TRUE)
scores <- as.data.frame(pca_res$x)
loadings <- as.data.frame(pca_res$rotation)

# ============================================================
# FIGURE 2 — SCREE PLOT
# ============================================================
save_tiff("Figure2_ScreePlot.tiff", quote({
  var_exp <- (pca_res$sdev^2) / sum(pca_res$sdev^2)
  plot(var_exp, type = "b", pch = 19,
       xlab = "Principal Component",
       ylab = "Variance Explained",
       main = "Scree Plot")
}))

# ============================================================
# FIGURE 3 — PCA BIPLOT
# ============================================================
save_tiff("Figure3_PCA_Biplot.tiff", quote({
  plot(scores$PC1, scores$PC2,
       pch = 19, col = rgb(0,0,0,0.4),
       xlab = "PC1", ylab = "PC2",
       main = "PCA Biplot")
  
  arrows(0,0, loadings$PC1*4, loadings$PC2*4, col="red")
  text(loadings$PC1*4, loadings$PC2*4,
       labels=rownames(loadings), col="red", cex=0.6)
}))

# ============================================================
# CLUSTERING
# ============================================================
scaled <- scale(analysis_df)
kmeans_model <- kmeans(scaled, centers = 2, nstart = 25)

pca_vis <- prcomp(scaled)
pca_df <- data.frame(
  PC1 = pca_vis$x[,1],
  PC2 = pca_vis$x[,2],
  Cluster = as.factor(kmeans_model$cluster)
)

# ============================================================
# FIGURE 4 — CLUSTER PLOT
# ============================================================
save_tiff("Figure4_ClusterPlot.tiff", quote({
  print(
    ggplot(pca_df, aes(PC1, PC2, color=Cluster)) +
      geom_point(alpha=0.7) +
      stat_ellipse() +
      theme_minimal() +
      labs(title="Cluster Separation (PCA)")
  )
}))

# ============================================================
# MODELING (PROXY TARGET)
# ============================================================
target_col <- category_columns[1]
predictors <- setdiff(category_columns, target_col)

model_df <- analysis_df[, c(target_col, predictors)]
names(model_df)[1] <- "target"

trainIndex <- createDataPartition(model_df$target, p=0.8, list=FALSE)
train <- model_df[trainIndex,]
test <- model_df[-trainIndex,]

rf_model <- randomForest(target ~ ., data=train)
rf_pred <- predict(rf_model, test)

pred_df <- data.frame(
  Actual = test$target,
  Predicted = rf_pred
)
pred_df$Residual <- pred_df$Actual - pred_df$Predicted

best_model_name <- "Random Forest"

# ============================================================
# FIGURE 5 — ACTUAL VS PREDICTED
# ============================================================
save_tiff("Figure5_Actual_vs_Predicted.tiff", quote({
  print(
    ggplot(pred_df, aes(Actual, Predicted)) +
      geom_point(alpha=0.5) +
      geom_abline(slope=1, intercept=0, linetype="dashed") +
      theme_minimal() +
      labs(title="Actual vs Predicted (Random Forest)")
  )
}))

# ============================================================
# FIGURE 6 — RESIDUAL PLOT
# ============================================================
save_tiff("Figure6_ResidualPlot.tiff", quote({
  print(
    ggplot(pred_df, aes(Predicted, Residual)) +
      geom_point(alpha=0.5) +
      geom_hline(yintercept=0, linetype="dashed") +
      theme_minimal() +
      labs(title="Residual Plot")
  )
}))

# ============================================================
# FIGURE 7 — FEATURE IMPORTANCE
# ============================================================
importance_df <- data.frame(
  Feature = rownames(importance(rf_model)),
  Importance = importance(rf_model)[,1]
)

save_tiff("Figure7_FeatureImportance.tiff", quote({
  print(
    ggplot(importance_df,
           aes(x=reorder(Feature, Importance), y=Importance)) +
      geom_col(fill="steelblue") +
      coord_flip() +
      theme_minimal() +
      labs(title="Feature Importance (Random Forest)")
  )
}))

cat("All 7 TIFF figures generated successfully.\n")
#--------------------------------------------------------------------------------------------------------------------------------------------------
# ============================================================
# HELIYON 2.0.2 — REVISED DISTINCT Q1 PIPELINE
#
# Research focus:
# Latent structure and cross-attribute predictability in
# structured beer-review data.
#
# Important distinction:
# This is NOT an aggregated-versus-raw comparison.
# review_overall is deliberately excluded from the proxy task
# to keep this study scientifically distinct from Heliyon 3.0.
# ============================================================


# ============================================================
# 0. USER SETTINGS
# ============================================================

data_path <- paste0(
  "C:/Users/sahlw/OneDrive/Desktop/YNU2/PROJECT/",
  "BEER REVIEW PREDICTION/DATASET/beer_reviews(1).xlsx"
)

output_dir <- paste0(
  "C:/Users/sahlw/OneDrive/Desktop/YNU2/PROJECT/",
  "BEER REVIEW PREDICTION/HELIYON_2_REVISED_OUTPUTS"
)

# Use the full dataset where computationally feasible.
# Set analysis_n <- 5456 only if the paper will explicitly state
# that a reproducible random analytical sample of 5,456 reviews
# was drawn from the full BeerAdvocate dataset.
analysis_n <- 5456

random_seed <- 123
set.seed(random_seed)

if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

setwd(output_dir)


# ============================================================
# 1. INSTALL AND LOAD PACKAGES
# ============================================================

required_packages <- c(
  "readxl",
  "dplyr",
  "tidyr",
  "ggplot2",
  "caret",
  "corrplot",
  "ranger",
  "kernlab",
  "cluster",
  "factoextra",
  "scales"
)

for (pkg in required_packages) {
  
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
  }
  
  library(pkg, character.only = TRUE)
}

set.seed(random_seed)


# ============================================================
# 2. LOAD AND VERIFY THE ACTUAL DATASET
# Reviewer Steps 1–3:
# - real variable names
# - target consistency
# - precise dataset documentation
# ============================================================

beer_data <- readxl::read_excel(data_path)

names(beer_data) <- make.names(
  names(beer_data),
  unique = TRUE
)

cat("\nOriginal dataset dimensions:\n")
print(dim(beer_data))

cat("\nActual source variables:\n")
print(names(beer_data))

expected_columns <- c(
  "brewery_id",
  "brewery_name",
  "review_time",
  "review_overall",
  "review_aroma",
  "review_appearance",
  "review_profilename",
  "beer_style",
  "review_palate",
  "review_taste",
  "beer_name",
  "beer_abv",
  "beer_beerid"
)

missing_columns <- setdiff(
  expected_columns,
  names(beer_data)
)

if (length(missing_columns) > 0) {
  stop(
    "The following expected variables are missing: ",
    paste(missing_columns, collapse = ", ")
  )
}


# ============================================================
# 3. DATA DICTIONARY
# Reviewer Step 1: identify variables everywhere
# ============================================================

data_dictionary <- data.frame(
  Variable = c(
    "review_aroma",
    "review_appearance",
    "review_palate",
    "review_taste",
    "beer_abv",
    "review_overall",
    "review_profilename",
    "beer_beerid"
  ),
  
  Manuscript_Label = c(
    "Aroma",
    "Appearance",
    "Palate",
    "Taste",
    "Alcohol by volume",
    "Overall rating",
    "Reviewer identifier",
    "Beer identifier"
  ),
  
  Description = c(
    "User-assigned aroma score",
    "User-assigned appearance score",
    "User-assigned palate or mouthfeel score",
    "User-assigned taste score; designated proxy response",
    "Alcohol by volume (%)",
    paste(
      "User-assigned overall score; retained for descriptive",
      "documentation but excluded from the proxy prediction task"
    ),
    "Anonymous reviewer profile identifier",
    "Unique beer identifier"
  )
)

write.csv(
  data_dictionary,
  "Supplementary_Table_S1_Data_Dictionary.csv",
  row.names = FALSE
)

print(data_dictionary)


# ============================================================
# 4. CLEAN NUMERICAL VARIABLES
# ============================================================

numeric_variables <- c(
  "review_aroma",
  "review_appearance",
  "review_palate",
  "review_taste",
  "beer_abv",
  "review_overall"
)

beer_data <- beer_data %>%
  mutate(
    across(
      all_of(numeric_variables),
      ~ suppressWarnings(as.numeric(.x))
    )
  )

# Remove observations without the verified proxy response.
beer_data <- beer_data %>%
  filter(!is.na(review_taste))

# Median imputation for predictors only.
predictor_variables <- c(
  "review_aroma",
  "review_appearance",
  "review_palate",
  "beer_abv"
)

for (variable in predictor_variables) {
  
  variable_median <- median(
    beer_data[[variable]],
    na.rm = TRUE
  )
  
  if (!is.finite(variable_median)) {
    stop(
      "Median could not be calculated for ",
      variable
    )
  }
  
  beer_data[[variable]][
    is.na(beer_data[[variable]])
  ] <- variable_median
}


# ============================================================
# 5. CREATE A REPRODUCIBLE ANALYTICAL SAMPLE
#
# Do not describe this as the original dataset.
# Describe it as a reproducible analytical sample from the
# full BeerAdvocate corpus.
# ============================================================

set.seed(random_seed)

if (
  !is.null(analysis_n) &&
  nrow(beer_data) > analysis_n
) {
  
  analysis_data <- beer_data %>%
    slice_sample(n = analysis_n)
  
} else {
  
  analysis_data <- beer_data
}

cat("\nAnalytical sample dimensions:\n")
print(dim(analysis_data))

cat("\nNumber of unique reviewers:\n")
print(n_distinct(analysis_data$review_profilename))

cat("\nNumber of unique beers:\n")
print(n_distinct(analysis_data$beer_beerid))


# ============================================================
# 6. ANALYSIS VARIABLES
#
# review_overall is not used because Heliyon 2.0.2 examines
# inter-attribute predictability, not overall-rating prediction.
# ============================================================

sensory_variables <- c(
  "review_aroma",
  "review_appearance",
  "review_palate",
  "review_taste"
)

proxy_target <- "review_taste"

proxy_predictors <- c(
  "review_aroma",
  "review_appearance",
  "review_palate",
  "beer_abv"
)

sensory_df <- analysis_data %>%
  select(all_of(sensory_variables)) %>%
  na.omit()

model_df <- analysis_data %>%
  select(
    all_of(proxy_target),
    all_of(proxy_predictors)
  ) %>%
  na.omit()

cat("\nVerified proxy target:\n")
print(proxy_target)

cat("\nProxy predictors:\n")
print(proxy_predictors)


# ============================================================
# 7. DESCRIPTIVE STATISTICS
# ============================================================

descriptive_statistics <- sensory_df %>%
  pivot_longer(
    cols = everything(),
    names_to = "Variable",
    values_to = "Value"
  ) %>%
  group_by(Variable) %>%
  summarise(
    N = n(),
    Mean = mean(Value, na.rm = TRUE),
    SD = sd(Value, na.rm = TRUE),
    Median = median(Value, na.rm = TRUE),
    Minimum = min(Value, na.rm = TRUE),
    Maximum = max(Value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    Variable = recode(
      Variable,
      review_aroma = "Aroma",
      review_appearance = "Appearance",
      review_palate = "Palate",
      review_taste = "Taste"
    )
  )

write.csv(
  descriptive_statistics,
  "Table1_Descriptive_Statistics.csv",
  row.names = FALSE
)

print(descriptive_statistics)


# ============================================================
# 8. HELPER FUNCTIONS
# ============================================================

save_tiff <- function(
    filename,
    plot_object,
    width = 9,
    height = 7,
    dpi = 300
) {
  
  ggsave(
    filename = filename,
    plot = plot_object,
    width = width,
    height = height,
    units = "in",
    dpi = dpi,
    compression = "lzw",
    bg = "white"
  )
}

publication_theme <- theme_minimal(base_size = 16) +
  theme(
    plot.title = element_text(
      face = "bold",
      size = 19,
      hjust = 0.5
    ),
    plot.subtitle = element_text(
      size = 13,
      hjust = 0.5
    ),
    axis.title = element_text(
      face = "bold",
      size = 14
    ),
    axis.text = element_text(size = 12),
    legend.title = element_text(
      face = "bold"
    ),
    panel.grid.minor = element_blank()
  )


# ============================================================
# 9. CORRELATION ANALYSIS
# Reviewer Step 7: report actual coefficients
# ============================================================

cor_matrix <- cor(
  sensory_df,
  use = "pairwise.complete.obs",
  method = "pearson"
)

# Rename matrix for publication.
publication_names <- c(
  review_aroma = "Aroma",
  review_appearance = "Appearance",
  review_palate = "Palate",
  review_taste = "Taste"
)

rownames(cor_matrix) <- publication_names[
  rownames(cor_matrix)
]

colnames(cor_matrix) <- publication_names[
  colnames(cor_matrix)
]

# Extract unique off-diagonal correlations.
correlation_table <- as.data.frame(
  as.table(cor_matrix)
) %>%
  rename(
    Variable_1 = Var1,
    Variable_2 = Var2,
    Correlation = Freq
  ) %>%
  filter(Variable_1 != Variable_2) %>%
  rowwise() %>%
  mutate(
    Pair = paste(
      sort(c(
        as.character(Variable_1),
        as.character(Variable_2)
      )),
      collapse = " – "
    )
  ) %>%
  ungroup() %>%
  distinct(Pair, .keep_all = TRUE) %>%
  mutate(
    Absolute_Correlation = abs(Correlation)
  ) %>%
  arrange(desc(Absolute_Correlation))

write.csv(
  correlation_table,
  "Table2_Correlation_Coefficients.csv",
  row.names = FALSE
)

cat("\nStrongest correlations:\n")
print(
  correlation_table %>%
    select(Pair, Correlation) %>%
    slice_head(n = 5)
)


# ============================================================
# FIGURE 1 — PUBLICATION HEATMAP WITH REAL NAMES
# ============================================================

heatmap_data <- as.data.frame(
  as.table(cor_matrix)
)

figure1 <- ggplot(
  heatmap_data,
  aes(
    x = Var1,
    y = Var2,
    fill = Freq
  )
) +
  geom_tile() +
  geom_text(
    aes(label = sprintf("%.2f", Freq)),
    size = 4.3
  ) +
  scale_fill_gradient2(
    low = "#2166AC",
    mid = "white",
    high = "#B2182B",
    midpoint = 0,
    limits = c(-1, 1),
    name = "Pearson r"
  ) +
  coord_equal() +
  labs(
    title = "Correlation Structure of Sensory Rating Dimensions",
    subtitle = "Cell values represent Pearson correlation coefficients",
    x = NULL,
    y = NULL
  ) +
  publication_theme +
  theme(
    axis.text.x = element_text(
      angle = 0,
      face = "bold"
    ),
    axis.text.y = element_text(
      face = "bold"
    ),
    panel.grid = element_blank()
  )

save_tiff(
  "Figure1_Correlation_Heatmap.tiff",
  figure1,
  width = 8,
  height = 7
)


# ============================================================
# 10. PCA
# Reviewer Step 6: cautious interpretation and PC1–PC3 view
# ============================================================

pca_result <- prcomp(
  sensory_df,
  center = TRUE,
  scale. = TRUE
)

variance_explained <- (
  pca_result$sdev^2 /
    sum(pca_result$sdev^2)
)

pca_variance_table <- data.frame(
  Principal_Component = paste0(
    "PC",
    seq_along(variance_explained)
  ),
  Variance_Explained = variance_explained,
  Cumulative_Variance = cumsum(
    variance_explained
  )
)

write.csv(
  pca_variance_table,
  "Table3_PCA_Variance_Explained.csv",
  row.names = FALSE
)

cat("\nPCA variance explained:\n")
print(pca_variance_table)

pca_scores <- as.data.frame(
  pca_result$x
)

pca_loadings <- as.data.frame(
  pca_result$rotation
)

pca_loadings$Variable <- rownames(
  pca_loadings
)

pca_loadings$Variable <- recode(
  pca_loadings$Variable,
  review_aroma = "Aroma",
  review_appearance = "Appearance",
  review_palate = "Palate",
  review_taste = "Taste"
)


# ============================================================
# FIGURE 2 — SCREE PLOT
# ============================================================

scree_df <- data.frame(
  Component = seq_along(
    variance_explained
  ),
  Variance = variance_explained * 100,
  Cumulative = cumsum(
    variance_explained
  ) * 100
)

figure2 <- ggplot(
  scree_df,
  aes(
    x = Component,
    y = Variance
  )
) +
  geom_line(linewidth = 0.9) +
  geom_point(size = 3) +
  scale_x_continuous(
    breaks = scree_df$Component
  ) +
  labs(
    title = "Variance Explained by Principal Components",
    subtitle = paste0(
      "PC1 and PC2 jointly explain ",
      round(
        sum(variance_explained[1:2]) * 100,
        2
      ),
      "% of total variance"
    ),
    x = "Principal component",
    y = "Variance explained (%)"
  ) +
  publication_theme

save_tiff(
  "Figure2_Scree_Plot.tiff",
  figure2,
  width = 8,
  height = 6
)


# ============================================================
# FIGURE 3 — PC1–PC2 BIPLOT
#
# It is explicitly described as a partial two-dimensional view.
# ============================================================

loading_scale <- 4

figure3 <- ggplot(
  pca_scores,
  aes(
    x = PC1,
    y = PC2
  )
) +
  geom_point(
    alpha = 0.25,
    size = 1.2
  ) +
  geom_segment(
    data = pca_loadings,
    aes(
      x = 0,
      y = 0,
      xend = PC1 * loading_scale,
      yend = PC2 * loading_scale
    ),
    arrow = arrow(
      length = unit(0.18, "cm")
    ),
    linewidth = 0.8,
    inherit.aes = FALSE
  ) +
  geom_text(
    data = pca_loadings,
    aes(
      x = PC1 * loading_scale * 1.12,
      y = PC2 * loading_scale * 1.12,
      label = Variable
    ),
    size = 4.5,
    fontface = "bold",
    inherit.aes = FALSE
  ) +
  labs(
    title = "Partial PCA Representation of Sensory Ratings",
    subtitle = paste0(
      "The PC1–PC2 projection represents ",
      round(
        sum(variance_explained[1:2]) * 100,
        2
      ),
      "% of total variance"
    ),
    x = paste0(
      "PC1 (",
      round(
        variance_explained[1] * 100,
        1
      ),
      "%)"
    ),
    y = paste0(
      "PC2 (",
      round(
        variance_explained[2] * 100,
        1
      ),
      "%)"
    )
  ) +
  publication_theme

save_tiff(
  "Figure3_PCA_Biplot_PC1_PC2.tiff",
  figure3,
  width = 9,
  height = 7
)


# ============================================================
# SUPPLEMENTARY FIGURE S1 — PC1–PC3
# Reviewer requested an optional second projection.
# ============================================================

figure_s1 <- ggplot(
  pca_scores,
  aes(
    x = PC1,
    y = PC3
  )
) +
  geom_point(
    alpha = 0.25,
    size = 1.2
  ) +
  geom_segment(
    data = pca_loadings,
    aes(
      x = 0,
      y = 0,
      xend = PC1 * loading_scale,
      yend = PC3 * loading_scale
    ),
    arrow = arrow(
      length = unit(0.18, "cm")
    ),
    linewidth = 0.8,
    inherit.aes = FALSE
  ) +
  geom_text(
    data = pca_loadings,
    aes(
      x = PC1 * loading_scale * 1.12,
      y = PC3 * loading_scale * 1.12,
      label = Variable
    ),
    size = 4.5,
    fontface = "bold",
    inherit.aes = FALSE
  ) +
  labs(
    title = "Supplementary PC1–PC3 Projection",
    subtitle = paste0(
      "PC1 and PC3 jointly explain ",
      round(
        sum(
          variance_explained[c(1, 3)]
        ) * 100,
        2
      ),
      "% of total variance"
    ),
    x = paste0(
      "PC1 (",
      round(
        variance_explained[1] * 100,
        1
      ),
      "%)"
    ),
    y = paste0(
      "PC3 (",
      round(
        variance_explained[3] * 100,
        1
      ),
      "%)"
    )
  ) +
  publication_theme

save_tiff(
  "FigureS1_PCA_PC1_PC3.tiff",
  figure_s1,
  width = 9,
  height = 7
)


# ============================================================
# 11. CLUSTERING WITH SILHOUETTE VALIDATION
# ============================================================

scaled_sensory <- scale(
  sensory_df
)

# Assess candidate k values.
silhouette_results <- data.frame(
  K = 2:6,
  Mean_Silhouette = NA_real_
)

set.seed(random_seed)

for (i in seq_along(
  silhouette_results$K
)) {
  
  k_value <- silhouette_results$K[i]
  
  k_fit <- kmeans(
    scaled_sensory,
    centers = k_value,
    nstart = 50
  )
  
  sil <- silhouette(
    k_fit$cluster,
    dist(scaled_sensory)
  )
  
  silhouette_results$Mean_Silhouette[i] <- mean(
    sil[, "sil_width"]
  )
}

write.csv(
  silhouette_results,
  "Supplementary_Table_S2_Silhouette_Validation.csv",
  row.names = FALSE
)

best_k <- silhouette_results$K[
  which.max(
    silhouette_results$Mean_Silhouette
  )
]

cat("\nSilhouette validation:\n")
print(silhouette_results)

cat("\nSelected number of clusters:\n")
print(best_k)

set.seed(random_seed)

kmeans_model <- kmeans(
  scaled_sensory,
  centers = best_k,
  nstart = 100
)

cluster_pca_df <- pca_scores %>%
  mutate(
    Cluster = factor(
      kmeans_model$cluster
    )
  )


# ============================================================
# 12. COMPLETE CLUSTER PROFILE TABLE
# Reviewer Step 8: no unexplained ten-variable selection
# ============================================================

cluster_profile_data <- sensory_df %>%
  mutate(
    Cluster = factor(
      kmeans_model$cluster
    )
  )

complete_cluster_profile <- cluster_profile_data %>%
  group_by(Cluster) %>%
  summarise(
    across(
      all_of(sensory_variables),
      ~ mean(.x, na.rm = TRUE)
    ),
    Count = n(),
    .groups = "drop"
  )

write.csv(
  complete_cluster_profile,
  "Supplementary_Table_S3_Complete_Cluster_Profile.csv",
  row.names = FALSE
)

cluster_long <- complete_cluster_profile %>%
  pivot_longer(
    cols = all_of(sensory_variables),
    names_to = "Variable",
    values_to = "Mean"
  ) %>%
  mutate(
    Variable = recode(
      Variable,
      review_aroma = "Aroma",
      review_appearance = "Appearance",
      review_palate = "Palate",
      review_taste = "Taste"
    )
  )

cluster_difference_table <- cluster_long %>%
  select(
    Cluster,
    Variable,
    Mean
  ) %>%
  pivot_wider(
    names_from = Cluster,
    values_from = Mean,
    names_prefix = "Cluster_"
  )

cluster_columns <- grep(
  "^Cluster_",
  names(cluster_difference_table),
  value = TRUE
)

if (length(cluster_columns) == 2) {
  
  cluster_difference_table <-
    cluster_difference_table %>%
    mutate(
      Absolute_Mean_Difference = abs(
        .data[[cluster_columns[1]]] -
          .data[[cluster_columns[2]]]
      )
    ) %>%
    arrange(
      desc(
        Absolute_Mean_Difference
      )
    )
}

write.csv(
  cluster_difference_table,
  "Table4_Cluster_Profile_Differences.csv",
  row.names = FALSE
)

print(cluster_difference_table)


# ============================================================
# FIGURE 4 — CLUSTER SEPARATION
# ============================================================

figure4 <- ggplot(
  cluster_pca_df,
  aes(
    x = PC1,
    y = PC2,
    shape = Cluster
  )
) +
  geom_point(
    alpha = 0.55,
    size = 1.7
  ) +
  stat_ellipse(
    linewidth = 0.9,
    level = 0.95
  ) +
  labs(
    title = "Cluster Profiles Projected onto PC1 and PC2",
    subtitle = paste0(
      "K = ",
      best_k,
      " selected using mean silhouette width"
    ),
    x = paste0(
      "PC1 (",
      round(
        variance_explained[1] * 100,
        1
      ),
      "%)"
    ),
    y = paste0(
      "PC2 (",
      round(
        variance_explained[2] * 100,
        1
      ),
      "%)"
    )
  ) +
  publication_theme

save_tiff(
  "Figure4_Cluster_Profiles.tiff",
  figure4,
  width = 9,
  height = 7
)


# ============================================================
# 13. PROXY-TASK MODELING
# Reviewer Steps 2 and 4:
# - one verified target everywhere
# - cautious proxy-task interpretation
# ============================================================

names(model_df)[
  names(model_df) == proxy_target
] <- "Proxy_Target"

set.seed(random_seed)

training_index <- createDataPartition(
  model_df$Proxy_Target,
  p = 0.80,
  list = FALSE
)

training_data <- model_df[
  training_index,
]

testing_data <- model_df[
  -training_index,
]


# ============================================================
# 14. MATCHED CROSS-VALIDATION FOLDS
# Reviewer Step 10: RF versus SVR paired comparison
# ============================================================

set.seed(random_seed)

cv_folds <- createFolds(
  training_data$Proxy_Target,
  k = 10,
  returnTrain = TRUE
)

cv_control <- trainControl(
  method = "cv",
  number = 10,
  index = cv_folds,
  savePredictions = "final",
  returnResamp = "all",
  allowParallel = TRUE
)


# ============================================================
# 15. LINEAR REGRESSION BASELINE
# ============================================================

set.seed(random_seed)

lm_model <- train(
  Proxy_Target ~ .,
  data = training_data,
  method = "lm",
  trControl = cv_control,
  metric = "RMSE",
  preProcess = c(
    "center",
    "scale"
  )
)


# ============================================================
# 16. RANDOM FOREST WITH PERMUTATION IMPORTANCE
# Reviewer Step 9: metric explicitly named
# ============================================================

rf_grid <- expand.grid(
  mtry = seq_len(
    ncol(training_data) - 1
  ),
  splitrule = "variance",
  min.node.size = c(5, 10)
)

set.seed(random_seed)

rf_model <- train(
  Proxy_Target ~ .,
  data = training_data,
  method = "ranger",
  trControl = cv_control,
  tuneGrid = rf_grid,
  metric = "RMSE",
  num.trees = 500,
  importance = "permutation"
)


# ============================================================
# 17. SUPPORT VECTOR REGRESSION
# ============================================================

svr_grid <- expand.grid(
  sigma = c(
    0.005,
    0.01,
    0.02,
    0.05
  ),
  C = c(
    1,
    5,
    10
  )
)

set.seed(random_seed)

svr_model <- train(
  Proxy_Target ~ .,
  data = training_data,
  method = "svmRadial",
  trControl = cv_control,
  tuneGrid = svr_grid,
  metric = "RMSE",
  preProcess = c(
    "center",
    "scale"
  )
)


# ============================================================
# 18. TEST-SET PREDICTIONS
# ============================================================

lm_prediction <- predict(
  lm_model,
  newdata = testing_data
)

rf_prediction <- predict(
  rf_model,
  newdata = testing_data
)

svr_prediction <- predict(
  svr_model,
  newdata = testing_data
)

# Weighted RF–SVR ensemble.
# Weights favor the stronger cross-validated model.
rf_cv_rmse_mean <- min(
  rf_model$results$RMSE
)

svr_cv_rmse_mean <- min(
  svr_model$results$RMSE
)

inverse_errors <- c(
  RF = 1 / rf_cv_rmse_mean,
  SVR = 1 / svr_cv_rmse_mean
)

ensemble_weights <- inverse_errors /
  sum(inverse_errors)

ensemble_prediction <-
  ensemble_weights["RF"] * rf_prediction +
  ensemble_weights["SVR"] * svr_prediction


# ============================================================
# 19. PERFORMANCE FUNCTIONS
# ============================================================

calculate_metrics <- function(
    observed,
    predicted,
    model_name
) {
  
  data.frame(
    Model = model_name,
    MAE = MAE(
      predicted,
      observed
    ),
    RMSE = RMSE(
      predicted,
      observed
    ),
    R2 = R2(
      predicted,
      observed
    )
  )
}

model_results <- bind_rows(
  calculate_metrics(
    testing_data$Proxy_Target,
    lm_prediction,
    "Linear Regression"
  ),
  
  calculate_metrics(
    testing_data$Proxy_Target,
    rf_prediction,
    "Random Forest"
  ),
  
  calculate_metrics(
    testing_data$Proxy_Target,
    svr_prediction,
    "Support Vector Regression"
  ),
  
  calculate_metrics(
    testing_data$Proxy_Target,
    ensemble_prediction,
    "Weighted RF–SVR Ensemble"
  )
) %>%
  arrange(RMSE)

write.csv(
  model_results,
  "Table5_Proxy_Task_Model_Performance.csv",
  row.names = FALSE
)

cat("\nTest-set performance:\n")
print(model_results)

cat("\nEnsemble weights:\n")
print(ensemble_weights)


# ============================================================
# 20. SHUFFLED-TARGET NEGATIVE CONTROL
#
# This validates that predictive performance is not produced
# merely by model flexibility.
# ============================================================

set.seed(random_seed)

shuffled_training <- training_data %>%
  mutate(
    Proxy_Target = sample(
      Proxy_Target
    )
  )

shuffled_rf <- train(
  Proxy_Target ~ .,
  data = shuffled_training,
  method = "ranger",
  trControl = cv_control,
  tuneGrid = rf_model$bestTune,
  metric = "RMSE",
  num.trees = 500,
  importance = "permutation"
)

shuffled_prediction <- predict(
  shuffled_rf,
  newdata = testing_data
)

shuffled_results <- bind_rows(
  calculate_metrics(
    testing_data$Proxy_Target,
    rf_prediction,
    "Observed proxy target"
  ),
  
  calculate_metrics(
    testing_data$Proxy_Target,
    shuffled_prediction,
    "Shuffled proxy target"
  )
)

write.csv(
  shuffled_results,
  "Supplementary_Table_S4_Shuffled_Target_Benchmark.csv",
  row.names = FALSE
)

cat("\nShuffled-target benchmark:\n")
print(shuffled_results)


# ============================================================
# 21. PAIRED RF–SVR SIGNIFICANCE TEST
# Reviewer Step 10
# ============================================================

rf_resamples <- rf_model$resample %>%
  select(
    Resample,
    RF_RMSE = RMSE
  )

svr_resamples <- svr_model$resample %>%
  select(
    Resample,
    SVR_RMSE = RMSE
  )

paired_resamples <- inner_join(
  rf_resamples,
  svr_resamples,
  by = "Resample"
) %>%
  mutate(
    Difference = SVR_RMSE - RF_RMSE
  )

write.csv(
  paired_resamples,
  "Table6_RF_SVR_CrossValidation_RMSE.csv",
  row.names = FALSE
)

normality_test <- shapiro.test(
  paired_resamples$Difference
)

if (
  normality_test$p.value >= 0.05
) {
  
  significance_test <- t.test(
    paired_resamples$RF_RMSE,
    paired_resamples$SVR_RMSE,
    paired = TRUE
  )
  
  test_name <- "Paired t-test"
  
} else {
  
  significance_test <- wilcox.test(
    paired_resamples$RF_RMSE,
    paired_resamples$SVR_RMSE,
    paired = TRUE,
    exact = FALSE
  )
  
  test_name <- paste(
    "Wilcoxon signed-rank test"
  )
}

significance_summary <- data.frame(
  Test = test_name,
  RF_Mean_CV_RMSE = mean(
    paired_resamples$RF_RMSE
  ),
  SVR_Mean_CV_RMSE = mean(
    paired_resamples$SVR_RMSE
  ),
  Mean_Difference_SVR_Minus_RF = mean(
    paired_resamples$Difference
  ),
  P_Value = significance_test$p.value,
  Shapiro_P_Value = normality_test$p.value
)

write.csv(
  significance_summary,
  "Table7_RF_vs_SVR_Significance_Test.csv",
  row.names = FALSE
)

cat("\nRF versus SVR paired comparison:\n")
print(significance_summary)

print(significance_test)


# ============================================================
# 22. BEST MODEL DIAGNOSTICS
# ============================================================

best_model_row <- model_results %>%
  slice(1)

best_model_name <- best_model_row$Model

if (
  best_model_name == "Random Forest"
) {
  
  best_prediction <- rf_prediction
  
} else if (
  best_model_name ==
  "Support Vector Regression"
) {
  
  best_prediction <- svr_prediction
  
} else if (
  best_model_name ==
  "Weighted RF–SVR Ensemble"
) {
  
  best_prediction <- ensemble_prediction
  
} else {
  
  best_prediction <- lm_prediction
}

prediction_df <- data.frame(
  Actual = testing_data$Proxy_Target,
  Predicted = best_prediction
) %>%
  mutate(
    Residual = Actual - Predicted
  )


# ============================================================
# FIGURE 5 — ACTUAL VERSUS PREDICTED
# ============================================================

figure5 <- ggplot(
  prediction_df,
  aes(
    x = Actual,
    y = Predicted
  )
) +
  geom_point(
    alpha = 0.45,
    size = 1.8
  ) +
  geom_abline(
    slope = 1,
    intercept = 0,
    linetype = "dashed",
    linewidth = 0.9
  ) +
  labs(
    title = "Observed versus Predicted Taste Scores",
    subtitle = paste(
      "Best proxy-task model:",
      best_model_name
    ),
    x = "Observed taste score",
    y = "Predicted taste score"
  ) +
  publication_theme

save_tiff(
  "Figure5_Observed_vs_Predicted.tiff",
  figure5,
  width = 8,
  height = 7
)


# ============================================================
# FIGURE 6 — RESIDUAL DIAGNOSTICS
# ============================================================

figure6 <- ggplot(
  prediction_df,
  aes(
    x = Predicted,
    y = Residual
  )
) +
  geom_point(
    alpha = 0.45,
    size = 1.8
  ) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    linewidth = 0.9
  ) +
  geom_smooth(
    method = "loess",
    se = FALSE,
    linewidth = 0.9
  ) +
  labs(
    title = "Residual Diagnostics for the Best Proxy-Task Model",
    subtitle = paste(
      "Residuals are defined as observed minus predicted",
      "taste scores"
    ),
    x = "Predicted taste score",
    y = "Residual"
  ) +
  publication_theme

save_tiff(
  "Figure6_Residual_Diagnostics.tiff",
  figure6,
  width = 8,
  height = 7
)


# ============================================================
# 23. PERMUTATION FEATURE IMPORTANCE
# Reviewer Step 9
# ============================================================

final_rf <- rf_model$finalModel

permutation_importance <- data.frame(
  Feature = names(
    final_rf$variable.importance
  ),
  Permutation_Importance = as.numeric(
    final_rf$variable.importance
  )
) %>%
  mutate(
    Feature_Label = recode(
      Feature,
      review_aroma = "Aroma",
      review_appearance = "Appearance",
      review_palate = "Palate",
      beer_abv = "Alcohol by volume"
    )
  ) %>%
  arrange(
    desc(
      Permutation_Importance
    )
  )

write.csv(
  permutation_importance,
  "Table8_RF_Permutation_Importance.csv",
  row.names = FALSE
)

cat("\nRandom Forest permutation importance:\n")
print(permutation_importance)


# ============================================================
# FIGURE 7 — PERMUTATION FEATURE IMPORTANCE
# ============================================================

figure7 <- ggplot(
  permutation_importance,
  aes(
    x = Permutation_Importance,
    y = reorder(
      Feature_Label,
      Permutation_Importance
    )
  )
) +
  geom_col(width = 0.68) +
  labs(
    title = "Permutation Importance for Taste-Score Prediction",
    subtitle = paste(
      "Importance reflects the reduction in predictive",
      "accuracy after predictor permutation"
    ),
    x = "Permutation importance",
    y = NULL
  ) +
  publication_theme +
  theme(
    axis.text.y = element_text(
      face = "bold"
    ),
    panel.grid.major.y = element_blank()
  )

save_tiff(
  "Figure7_RF_Permutation_Importance.tiff",
  figure7,
  width = 8,
  height = 6
)


# ============================================================
# 24. REPRODUCIBILITY RECORD
# ============================================================

sink(
  "Reproducibility_Record.txt"
)

cat(
  "Heliyon 2.0.2 revised proxy-task analysis\n\n"
)

cat(
  "Research task:\n",
  paste(
    "Prediction of review_taste from review_aroma,",
    "review_appearance, review_palate, and beer_abv.\n"
  )
)

cat(
  "\nExcluded outcome:\n",
  paste(
    "review_overall was excluded to avoid overlap with",
    "the Heliyon 3.0 overall-rating study.\n"
  )
)

cat(
  "\nOriginal observations:",
  nrow(beer_data),
  "\n"
)

cat(
  "Analytical observations:",
  nrow(analysis_data),
  "\n"
)

cat(
  "Random seed:",
  random_seed,
  "\n"
)

cat(
  "Selected clusters:",
  best_k,
  "\n\n"
)

cat(
  "RF best tuning parameters:\n"
)

print(
  rf_model$bestTune
)

cat(
  "\nSVR best tuning parameters:\n"
)

print(
  svr_model$bestTune
)

cat(
  "\nModel performance:\n"
)

print(
  model_results
)

cat(
  "\nRF versus SVR significance test:\n"
)

print(
  significance_summary
)

cat(
  "\nSession information:\n"
)

print(
  sessionInfo()
)

sink()


# ============================================================
# 25. FINAL FILE CHECK
# ============================================================

expected_outputs <- c(
  "Figure1_Correlation_Heatmap.tiff",
  "Figure2_Scree_Plot.tiff",
  "Figure3_PCA_Biplot_PC1_PC2.tiff",
  "Figure4_Cluster_Profiles.tiff",
  "Figure5_Observed_vs_Predicted.tiff",
  "Figure6_Residual_Diagnostics.tiff",
  "Figure7_RF_Permutation_Importance.tiff",
  "FigureS1_PCA_PC1_PC3.tiff",
  "Table1_Descriptive_Statistics.csv",
  "Table2_Correlation_Coefficients.csv",
  "Table3_PCA_Variance_Explained.csv",
  "Table4_Cluster_Profile_Differences.csv",
  "Table5_Proxy_Task_Model_Performance.csv",
  "Table6_RF_SVR_CrossValidation_RMSE.csv",
  "Table7_RF_vs_SVR_Significance_Test.csv",
  "Table8_RF_Permutation_Importance.csv",
  "Supplementary_Table_S1_Data_Dictionary.csv",
  "Supplementary_Table_S2_Silhouette_Validation.csv",
  "Supplementary_Table_S3_Complete_Cluster_Profile.csv",
  "Supplementary_Table_S4_Shuffled_Target_Benchmark.csv",
  "Reproducibility_Record.txt"
)

file_check <- data.frame(
  File = expected_outputs,
  Created = file.exists(
    expected_outputs
  )
)

print(file_check)

if (!all(file_check$Created)) {
  
  warning(
    paste(
      "Some expected output files were not generated:",
      paste(
        file_check$File[
          !file_check$Created
        ],
        collapse = ", "
      )
    )
  )
  
} else {
  
  cat(
    "\nAll revised Heliyon 2.0.2 outputs",
    "were generated successfully.\n"
  )
  
  cat(
    "Output directory:\n",
    normalizePath(output_dir),
    "\n"
  )
}